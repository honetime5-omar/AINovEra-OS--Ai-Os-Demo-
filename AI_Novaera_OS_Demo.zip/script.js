window.onload = function() {
  setTimeout(() => {
    document.getElementById('boot-screen').style.display = 'none';
    document.getElementById('main-ui').style.display = 'block';
  }, 3000);
};

function simulateDownload() {
  const status = document.getElementById('download-status');
  status.innerHTML = "AI optimizing...";
  setTimeout(() => {
    status.innerHTML = "✅ Song downloaded in 2s (AI assisted)";
  }, 2000);
}
