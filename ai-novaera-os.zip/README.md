# 🌌 AI Noværa OS — Futuristic Demo

**AI Noværa OS** je futuristički **sci-fi interaktivni operativni sistem** zamišljen kao *AI-powered OS pobjednika*.  
Radi potpuno u browseru (`index.html`), bez dodatnih dependencija.

---

## ✨ Funkcionalnosti

- 🔥 **Cinematic boot sekvenca** sa matrix kodom i glasovnim izgovorom.
- 🖐 **Stylized AI hand interface** sa orb-om koji lebdi i ostavlja glow trail.
- ⚙️ **Settings & Modules**: Self-Healing, Quantum Memory, AI Security, Neural Link, Battery Regen, Offline AI, Voice Core, Dimensional UI, Files, UltraSpeed Download, Browser, Call, Music
- 🗣 **Voice commands** (Chrome/Edge)
- 💡 **System log i procesi** (CPU/RAM/BAT)
- ✨ **3D efekti, glow trail, energy flash**

---

## 🚀 Pokretanje

1. Kloniraj ili preuzmi repo:
   ```bash
   git clone https://github.com/USERNAME/ai-novaera-os.git
   cd ai-novaera-os
   ```

2. Otvori fajl `index.html` u **Chrome** ili **Edge**.

3. Klikni **Start Boot** ili **Skip Boot** da uđeš u OS.

4. Aktiviraj glasovne komande klikom na **Start Voice** i dozvoli mikrofon.

---

## 🎮 Kontrole

- `1` → Open Call  
- `2` → Open Browser  
- `3` → Open Music  
- `4` → Self-Heal  

---

## 🔮 Vizija

Ovo nije pravi OS — ovo je **futuristička demonstracija** onoga što bi **AI-vođen operativni sistem budućnosti** mogao izgledati.  
AI nije samo alat — **AI *je* sam OS**.

---

© 2025 — **AI Noværa OS Demo**  
Licenca: MIT
