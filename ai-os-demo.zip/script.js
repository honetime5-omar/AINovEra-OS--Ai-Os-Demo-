let progress = 0;
let bootInterval = setInterval(() => {
  progress += 10;
  document.getElementById('progress').textContent = progress + '%';
  if (progress >= 100) {
    clearInterval(bootInterval);
    document.getElementById('boot').classList.add('hidden');
    document.getElementById('menu').classList.remove('hidden');
  }
}, 500);

function startCall() {
  document.getElementById('output').innerText = 'Dialing...\nAI: Hey, šta ima?\nYou: Ništa, kod tebe?\nAI: Radim na kernelu 😉';
}
function openBrowser() {
  document.getElementById('output').innerText = 'AI Browser Opened...\nSearching: "Futuristic AI OS"\nResults:\n1. Speed beyond limits\n2. Healing kernel demo';
}
function downloadSong() {
  document.getElementById('output').innerText = 'Downloading song...\nSpeed: 2s complete!\nAI: Futuristic Fast ⚡';
}
